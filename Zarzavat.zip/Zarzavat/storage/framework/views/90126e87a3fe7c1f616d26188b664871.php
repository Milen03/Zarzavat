<!-- filepath: /home/milen/Zarzavat/Zarzavat/resources/views/profile/edit.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h2 class="text-2xl font-semibold mb-4">Поръчка #<?php echo e($order->id); ?></h2>
        
        <?php if(session('success')): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
                <h3 class="text-lg font-medium mb-2">Информация за поръчката</h3>
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <p class="mb-2"><span class="font-medium">Номер:</span> <?php echo e($order->id); ?></p>
                    <p class="mb-2"><span class="font-medium">Дата:</span> <?php echo e($order->created_at->setTimezone('Europe/Sofia')->format('d.m.Y H:i')); ?></p>
                    <p class="mb-2"><span class="font-medium">Статус:</span> 
                        <?php if($order->status == 'pending'): ?>
                            <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">В очакване</span>
                        <?php elseif($order->status == 'processing'): ?>
                            <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">В обработка</span>
                        <?php elseif($order->status == 'completed'): ?>
                            <span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Изпълнена</span>
                        <?php elseif($order->status == 'cancelled'): ?>
                            <span class="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs">Отказана</span>
                        <?php endif; ?>
                    </p>
                    <p><span class="font-medium">Обща сума:</span> <?php echo e(number_format($order->total_price, 2)); ?> лв.</p>
                </div>
            </div>
            
            <div>
                <h3 class="text-lg font-medium mb-2">Информация за доставка</h3>
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <p class="mb-2"><span class="font-medium">Име:</span> <?php echo e($order->name); ?></p>
                    <p class="mb-2"><span class="font-medium">Имейл:</span> <?php echo e($order->email); ?></p>
                    <p class="mb-2"><span class="font-medium">Телефон:</span> <?php echo e($order->phone); ?></p>
                    <p><span class="font-medium">Адрес:</span> <?php echo e($order->address); ?></p>
                </div>
            </div>
        </div>
        
        <h3 class="text-lg font-medium mb-4">Продукти в поръчката</h3>
        
        <div class="overflow-x-auto">
            <table class="w-full bg-white border border-gray-300 rounded-lg">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">Продукт</th>
                        <th class="px-4 py-2 text-center">Цена</th>
                        <th class="px-4 py-2 text-center">Количество</th>
                        <th class="px-4 py-2 text-right">Общо</th>
                        <th class="px-4 py-2 text-center">Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t border-gray-200">
                        <td class="px-4 py-3">
                            <?php if($item->product): ?>
                                <?php echo e($item->product->name); ?>

                            <?php else: ?>
                                <span class="text-gray-500">Продуктът вече не е наличен</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-center"><?php echo e(number_format($item->price, 2)); ?> лв.</td>
                        <td class="px-4 py-3 text-center">
                            <?php if($order->status == 'pending'): ?>
                                <form action="<?php echo e(route('profile.update', $item->id)); ?>" method="POST" class="flex items-center justify-center">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" class="w-16 border border-gray-300 rounded px-2 py-1 text-center">
                                    <button type="submit" class="ml-2 bg-green-500 hover:bg-green-600 text-white rounded px-2 py-1 text-sm">
                                        Обнови
                                    </button>
                                </form>
                            <?php else: ?>
                                <?php echo e($item->quantity); ?>

                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-right"><?php echo e(number_format($item->price * $item->quantity, 2)); ?> лв.</td>
                        <td class="px-4 py-3 text-center">
                            <?php if($order->status == 'pending'): ?>
                                <form action="<?php echo e(route('profile.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Сигурни ли сте, че искате да премахнете този продукт?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white rounded px-2 py-1 text-sm">
                                        Премахни
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="text-gray-500 text-sm">Не може да се редактира</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr class="bg-gray-50">
                        <td colspan="3" class="px-4 py-3 text-right font-medium">Обща сума:</td>
                        <td class="px-4 py-3 text-right font-bold"><?php echo e(number_format($order->total_price, 2)); ?> лв.</td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        
    
        
        <div class="mt-6 text-center">
            <div class="flex justify-between items-center mb-4">
    <h3 class="text-lg font-medium">Продукти в поръчката</h3>
    
    <?php if($order->status == 'pending'): ?>
        <a href="<?php echo e(route('profile.add-item.form', $order->id)); ?>" class="bg-green-500 hover:bg-green-600 text-white py-1 px-4 rounded flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
            </svg>
            Добави продукт
        </a>
    <?php endif; ?>
            </div>
            <a href="<?php echo e(route('profile.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded">
                Назад към моите поръчки
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/milen/Zarzavat/Zarzavat/resources/views/profile/edit.blade.php ENDPATH**/ ?>