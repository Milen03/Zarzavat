
<!DOCTYPE html>
<html lang="bg" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Зеленчуков магазин</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="h-full m-0 p-0 flex flex-col bg-gray-100 text-gray-900">

    
    <nav class="w-full bg-white shadow">
        <div class="w-full px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <!-- Лого -->
            <a href="<?php echo e(route('products.index')); ?>" class="text-xl font-bold text-green-600">Зеленчуци</a>
            
            <!-- Навигационни линкове -->
            <div class="flex space-x-4 items-center">
                <a href="<?php echo e(route('products.index')); ?>" class="hover:text-green-600">Продукти</a>
                <a href="<?php echo e(route('cart.index')); ?>" class="hover:text-green-600">Количка</a>
                <a href="<?php echo e(route('profile.index')); ?>" class="hover:text-green-600">
                       <?php echo e(Auth::check() ? 'Моите поръчки' : 'Проследи поръчка'); ?>

                 </a>

                <?php if(auth()->guard()->check()): ?>
                    <span class="text-gray-700 hidden sm:inline">Здравей, <?php echo e(auth()->user()->name); ?></span>

                    <?php if(auth()->user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="hover:text-blue-600 font-semibold">
                            Админ панел
                        </a>
                    <?php endif; ?>

                    <!-- Logout -->
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-red-500 hover:text-red-700">
                            Изход
                        </button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="hover:text-green-600">Вход</a>
                    <a href="<?php echo e(route('register')); ?>" class="hover:text-green-600">Регистрация</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- MAIN CONTENT -->
    <main class="flex-grow w-full">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </main>
    
    <!-- FOOTER -->
    <footer class="w-full bg-white shadow py-4">
        <div class="w-full px-4 sm:px-6 lg:px-8 text-center text-gray-600">
            <p>© <?php echo e(date('Y')); ?> Зеленчуков магазин. Всички права запазени.</p>
        </div>
    </footer>

</body>
</html><?php /**PATH /home/milen/Zarzavat/Zarzavat/resources/views/layouts/app.blade.php ENDPATH**/ ?>