<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Поръчка #<?php echo e($order->id); ?></h1>

<div class="bg-white p-6 rounded shadow mb-4">
    <p><strong>Име:</strong> <?php echo e($order->user->name ?? $order->name); ?></p>
    <p><strong>Телефон:</strong> <?php echo e($order->phone); ?></p>
    <p><strong>Адрес:</strong> <?php echo e($order->address); ?></p>
    <p><strong>Обща цена:</strong> <?php echo e($order->total_price); ?> лв</p>
    <p><strong>Текущ статус:</strong> 
        <span class="px-2 py-1 rounded text-sm
        <?php if($order->status == 'pending'): ?> bg-yellow-100 text-yellow-800
        <?php elseif($order->status == 'processing'): ?> bg-blue-100 text-blue-800
        <?php elseif($order->status == 'completed'): ?> bg-green-100 text-green-800
        <?php elseif($order->status == 'cancelled'): ?> bg-red-100 text-red-800
        <?php endif; ?>">
            <?php echo e(ucfirst($order->status)); ?>

        </span>
    </p>

    <div class="mt-4">
        <form action="<?php echo e(route('admin.orders.update.status', $order)); ?>" method="POST" class="flex items-center space-x-2">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            
            <select name="status" class="border rounded px-2 py-1">
                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>В очакване</option>
                <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>В обработка</option>
                <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Изпълнена</option>
                <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Отказана</option>
            </select>
            
            <button type="submit" class="bg-blue-600 text-white px-4 py-1 rounded">
                Обнови статус
            </button>
        </form>
    </div>

    <div class="flex mt-4 space-x-4">
        <!-- Форма за изтриване на поръчка -->
        <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded" 
                onclick="return confirm('Сигурни ли сте, че искате да изтриете тази поръчка?')">
                Изтриване
            </button>
        </form>
    </div>
</div>

<h2 class="text-xl font-semibold mb-2">Продукти в поръчката:</h2>

<table class="w-full bg-white shadow rounded">
    <thead>
        <tr class="bg-gray-100 text-left">
            <th class="p-3">Продукт</th>
            <th class="p-3">Количество</th>
            <th class="p-3">Цена</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-t">
            <td class="p-3"><?php echo e($item->product->name); ?></td>
            <td class="p-3"><?php echo e($item->quantity); ?></td>
            <td class="p-3"><?php echo e($item->price); ?> лв</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/milen/Zarzavat/Zarzavat/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>